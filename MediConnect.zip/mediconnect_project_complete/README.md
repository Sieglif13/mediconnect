# MediConnect (Kotlin + Room) - Completed Project

Proyecto Android Studio: MediConnect, diseñado para gestionar medicamentos y citas.
Este paquete incluye:
- 10 Activities
- Room para almacenamiento local (Medications y Appointments)
- Formularios con validación (AddMedication, AddAppointment)
- Recordatorios diarios programados con AlarmManager y notificaciones
- Edición y eliminación de elementos en listas (click y long-press)
- Material components baseline

## Requisitos
- Android Studio Flamingo o más reciente (recomendado)
- JDK 17
- Conexión a internet para descargar dependencias Gradle

## Importar el proyecto
1. Descargar el ZIP y descomprimir.
2. En Android Studio: `File > Open` y selecciona la carpeta `mediconnect_project`.
3. Dejar que Gradle sincronice y descargue dependencias.
4. Ejecutar en emulador o dispositivo.

## Notas técnicas
- Las notificaciones se programan usando `AlarmManager.setRepeating` para demo; en producción se recomienda `WorkManager` o alarm APIs con exactitud según necesidad.
- Los request codes de alarm usan el hash de `med.name + med.time`. Si cambias nombre/hora, se reprograma.
- Para persistencia y escalabilidad añade repositorios y ViewModel + LiveData/Flow.

## Mejoras posibles
- Integrar WorkManager para recordatorios fiables.
- Añadir autenticación y sincronización a servidor/Cloud Firestore.
- Mejorar UI con Material3 y Templates.
