package com.example.mediconnect.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.mediconnect.R
import android.widget.Button

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        findViewById<Button>(R.id.btnRegisterSubmit).setOnClickListener {
            finish()
        }
    }
}
