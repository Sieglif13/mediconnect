package com.example.mediconnect.activities

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mediconnect.R
import com.example.mediconnect.adapters.MedicationAdapter
import com.example.mediconnect.data.db.AppDatabase
import com.example.mediconnect.data.models.Medication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MedicationListActivity : AppCompatActivity() {
    private lateinit var adapter: MedicationAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_medication_list)

        val rv = findViewById<RecyclerView>(R.id.rvMedications)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = MedicationAdapter(emptyList(), onClick = { med -> editMedication(med) }, onLongClick = { med -> confirmDelete(med) })
        rv.adapter = adapter

        findViewById<FloatingActionButton>(R.id.fabAddMed).setOnClickListener {
            startActivity(Intent(this, AddMedicationActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        loadMedications()
    }

    private fun loadMedications() {
        val db = AppDatabase.getDatabase(this)
        CoroutineScope(Dispatchers.IO).launch {
            val meds = db.medicationDao().getAll()
            withContext(Dispatchers.Main) {
                adapter.update(meds)
            }
        }
    }

    private fun editMedication(med: Medication) {
        val i = Intent(this, AddMedicationActivity::class.java)
        i.putExtra("med_id", med.id)
        startActivity(i)
    }

    private fun confirmDelete(med: Medication) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar medicamento")
            .setMessage("¿Deseas eliminar " + med.name + "?")
            .setPositiveButton("Eliminar") { _: DialogInterface, _: Int ->
                deleteMedication(med)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun deleteMedication(med: Medication) {
        val db = AppDatabase.getDatabase(this)
        CoroutineScope(Dispatchers.IO).launch {
            db.medicationDao().delete(med)
            // Optionally cancel alarm associated (using same requestCode)
            withContext(Dispatchers.Main) {
                loadMedications()
            }
        }
    }
}
