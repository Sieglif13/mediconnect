package com.example.mediconnect.activities

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mediconnect.R
import com.example.mediconnect.adapters.AppointmentAdapter
import com.example.mediconnect.data.db.AppDatabase
import com.example.mediconnect.data.models.Appointment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.google.android.material.floatingactionbutton.FloatingActionButton

class AppointmentListActivity : AppCompatActivity() {
    private lateinit var adapter: AppointmentAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_appointment_list)

        val rv = findViewById<RecyclerView>(R.id.rvAppointments)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = AppointmentAdapter(emptyList(), onClick = { app -> editAppointment(app) }, onLongClick = { app -> confirmDelete(app) })
        rv.adapter = adapter

        findViewById<FloatingActionButton>(R.id.fabAddAppointment).setOnClickListener {
            startActivity(Intent(this, AddAppointmentActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        loadAppointments()
    }

    private fun loadAppointments() {
        val db = AppDatabase.getDatabase(this)
        CoroutineScope(Dispatchers.IO).launch {
            val apps = db.appointmentDao().getAll()
            withContext(Dispatchers.Main) {
                adapter.update(apps)
            }
        }
    }

    private fun editAppointment(app: Appointment) {
        val i = Intent(this, AddAppointmentActivity::class.java)
        i.putExtra("app_id", app.id)
        startActivity(i)
    }

    private fun confirmDelete(app: Appointment) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar cita")
            .setMessage("¿Deseas eliminar la cita con " + app.doctor + "?")
            .setPositiveButton("Eliminar") { _: DialogInterface, _: Int ->
                deleteAppointment(app)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun deleteAppointment(app: Appointment) {
        val db = AppDatabase.getDatabase(this)
        CoroutineScope(Dispatchers.IO).launch {
            db.appointmentDao().delete(app)
            withContext(Dispatchers.Main) {
                loadAppointments()
            }
        }
    }
}
