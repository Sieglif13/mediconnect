package com.example.mediconnect.activities

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.mediconnect.R
import com.example.mediconnect.data.db.AppDatabase
import com.example.mediconnect.data.models.Medication
import com.example.mediconnect.notifications.NotificationReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AddMedicationActivity : AppCompatActivity() {
    private var editId: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_medication)

        val name = findViewById<EditText>(R.id.etMedName)
        val dose = findViewById<EditText>(R.id.etDose)
        val time = findViewById<EditText>(R.id.etTime)
        val duration = findViewById<EditText>(R.id.etDuration)
        val btnSave = findViewById<Button>(R.id.btnSaveMed)

        val db = AppDatabase.getDatabase(this)

        // If editing existing medication
        editId = intent.getLongExtra("med_id", 0)
        if (editId != 0L) {
            CoroutineScope(Dispatchers.IO).launch {
                val med = db.medicationDao().getAll().find { it.id == editId }
                med?.let {
                    runOnUiThread {
                        name.setText(it.name)
                        dose.setText(it.dose)
                        time.setText(it.time)
                        duration.setText(it.durationDays.toString())
                    }
                }
            }
        }

        btnSave.setOnClickListener {
            // Basic validation
            if (name.text.toString().trim().isEmpty()) {
                name.error = "Ingresa el nombre del medicamento"
                return@setOnClickListener
            }
            if (time.text.toString().trim().isEmpty()) {
                time.error = "Ingresa la hora (HH:mm)"
                return@setOnClickListener
            }

            // Try parse time HH:mm
            val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
            sdf.isLenient = false
            val parsedDate = try {
                sdf.parse(time.text.toString().trim())
            } catch (e: Exception) {
                null
            }
            if (parsedDate == null) {
                time.error = "Formato inválido (usa HH:mm)"
                return@setOnClickListener
            }

            val med = Medication(
                id = if (editId != 0L) editId else 0,
                name = name.text.toString(),
                dose = dose.text.toString(),
                time = time.text.toString(),
                durationDays = duration.text.toString().toIntOrNull() ?: 0
            )

            CoroutineScope(Dispatchers.IO).launch {
                val dbId = if (editId != 0L) {
                    db.medicationDao().update(med)
                    editId
                } else {
                    db.medicationDao().insert(med)
                }
                scheduleDailyAlarm(med)

                runOnUiThread {
                    Toast.makeText(this@AddMedicationActivity, "Medicamento guardado", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }

    private fun scheduleDailyAlarm(med: Medication) {
        // Parse time HH:mm and schedule alarm for next occurrence
        try {
            val parts = med.time.split(":")

            val hour = parts[0].toInt()
            val minute = parts[1].toInt()

            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, hour)
            cal.set(Calendar.MINUTE, minute)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)

            if (cal.timeInMillis <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_MONTH, 1)
            }

            val intent = Intent(this, NotificationReceiver::class.java)
            intent.putExtra("med_name", med.name)
            intent.putExtra("med_dose", med.dose)

            val requestCode = (med.name + med.time).hashCode()
            val pending = PendingIntent.getBroadcast(this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)

            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pending)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
