package com.example.mediconnect.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.mediconnect.R
import com.example.mediconnect.data.models.Appointment

class AppointmentAdapter(private var items: List<Appointment>,
                         private val onClick: (Appointment) -> Unit = {},
                         private val onLongClick: (Appointment) -> Unit = {}
) : RecyclerView.Adapter<AppointmentAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvDoctor: TextView = v.findViewById(R.id.tvDoctor)
        val tvDatetime: TextView = v.findViewById(R.id.tvDatetime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_appointment, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val a = items[position]
        holder.tvDoctor.text = a.doctor
        holder.tvDatetime.text = a.datetime

        holder.itemView.setOnClickListener { onClick(a) }
        holder.itemView.setOnLongClickListener {
            onLongClick(a)
            true
        }
    }

    override fun getItemCount(): Int = items.size

    fun update(newItems: List<Appointment>) {
        items = newItems
        notifyDataSetChanged()
    }
}
