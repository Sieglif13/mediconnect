package com.example.mediconnect.activities

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.mediconnect.R
import com.example.mediconnect.data.db.AppDatabase
import com.example.mediconnect.data.models.Appointment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AddAppointmentActivity : AppCompatActivity() {
    private var editId: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_appointment)

        val doctor = findViewById<EditText>(R.id.etDoctor)
        val specialty = findViewById<EditText>(R.id.etSpecialty)
        val datetime = findViewById<EditText>(R.id.etDatetime)
        val place = findViewById<EditText>(R.id.etPlace)
        val btnSave = findViewById<Button>(R.id.btnSaveAppointment)

        val db = AppDatabase.getDatabase(this)

        editId = intent.getLongExtra("app_id", 0)
        if (editId != 0L) {
            CoroutineScope(Dispatchers.IO).launch {
                val app = db.appointmentDao().getAll().find { it.id == editId }
                app?.let {
                    runOnUiThread {
                        doctor.setText(it.doctor)
                        specialty.setText(it.specialty)
                        datetime.setText(it.datetime)
                        place.setText(it.place)
                    }
                }
            }
        }

        btnSave.setOnClickListener {
            if (doctor.text.toString().trim().isEmpty()) {
                doctor.error = "Ingresa el nombre del médico"
                return@setOnClickListener
            }
            if (datetime.text.toString().trim().isEmpty()) {
                datetime.error = "Ingresa fecha y hora"
                return@setOnClickListener
            }

            val app = Appointment(
                id = if (editId != 0L) editId else 0,
                doctor = doctor.text.toString(),
                specialty = specialty.text.toString(),
                datetime = datetime.text.toString(),
                place = place.text.toString()
            )

            CoroutineScope(Dispatchers.IO).launch {
                if (editId != 0L) {
                    db.appointmentDao().update(app)
                } else {
                    db.appointmentDao().insert(app)
                }
                runOnUiThread {
                    Toast.makeText(this@AddAppointmentActivity, "Cita guardada", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }
}
