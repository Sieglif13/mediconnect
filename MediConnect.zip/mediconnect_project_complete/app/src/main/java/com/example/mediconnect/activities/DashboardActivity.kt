package com.example.mediconnect.activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.mediconnect.R
import android.widget.Button

class DashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        findViewById<Button>(R.id.btnMedications).setOnClickListener {
            startActivity(Intent(this, MedicationListActivity::class.java))
        }
        findViewById<Button>(R.id.btnAppointments).setOnClickListener {
            startActivity(Intent(this, AppointmentListActivity::class.java))
        }
        findViewById<Button>(R.id.btnProfile).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
    }
}
