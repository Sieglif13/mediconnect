package com.example.mediconnect.data.db

import androidx.room.*
import com.example.mediconnect.data.models.Appointment

@Dao
interface AppointmentDao {
    @Query("SELECT * FROM appointments ORDER BY datetime")
    suspend fun getAll(): List<Appointment>

    @Insert
    suspend fun insert(app: Appointment): Long

    @Update
    suspend fun update(app: Appointment)

    @Delete
    suspend fun delete(app: Appointment)
}
