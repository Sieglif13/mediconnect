package com.example.mediconnect.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "appointments")
data class Appointment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val doctor: String,
    val specialty: String,
    val datetime: String,
    val place: String
)
