package com.example.mediconnect.data.db

import androidx.room.*
import com.example.mediconnect.data.models.Medication

@Dao
interface MedicationDao {
    @Query("SELECT * FROM medications ORDER BY time")
    suspend fun getAll(): List<Medication>

    @Insert
    suspend fun insert(med: Medication): Long

    @Update
    suspend fun update(med: Medication)

    @Delete
    suspend fun delete(med: Medication)
}
